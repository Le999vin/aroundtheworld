export { cityDatasets, countryDatasets } from "@/lib/data/pois/registry.generated";
export type { CityDataset } from "@/lib/data/pois/registry.generated";
