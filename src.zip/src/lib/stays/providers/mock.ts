import fs from "node:fs/promises";
import path from "node:path";
import { countryMeta } from "@/lib/countries/countryMeta";
import { ServiceError } from "@/lib/services/errors";
import type { Bbox, Stay } from "@/lib/stays/types";

type StaySearchParams = {
  bbox: Bbox;
  minPrice?: number;
  maxPrice?: number;
  currency?: string;
  country?: string;
  limit?: number;
};

let staysCache: Stay[] | null = null;
let staysCachePromise: Promise<Stay[]> | null = null;

const resolveMockPath = () =>
  path.join(process.cwd(), "public", "data", "stays.mock.json");

const normalizeCountryCode = (value: unknown) => {
  if (typeof value !== "string") return "";
  const trimmed = value.trim().toUpperCase();
  return /^[A-Z]{2}$/.test(trimmed) ? trimmed : "";
};

const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

const clampLat = (value: number) => Math.max(-89.999, Math.min(89.999, value));
const clampLon = (value: number) =>
  Math.max(-179.999, Math.min(179.999, value));

const hashString = (value: string) => {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
};

const createRng = (seed: number) => {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let result = t;
    result = Math.imul(result ^ (result >>> 15), result | 1);
    result ^= result + Math.imul(result ^ (result >>> 7), result | 61);
    return ((result ^ (result >>> 14)) >>> 0) / 4294967296;
  };
};

const imagePool = [
  "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=500&q=70",
  "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=500&q=70",
  "https://images.unsplash.com/photo-1505691723518-36a5ac3be353?auto=format&fit=crop&w=500&q=70",
  "https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&w=500&q=70",
  "https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=500&q=70",
  "https://images.unsplash.com/photo-1502672023488-70e25813eb80?auto=format&fit=crop&w=500&q=70",
  "https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=500&q=70",
  "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=500&q=70",
];

const normalizeStay = (entry: unknown): Stay | null => {
  if (!entry || typeof entry !== "object") return null;
  const candidate = entry as Record<string, unknown>;
  const id =
    typeof candidate.id === "string"
      ? candidate.id
      : typeof candidate.id === "number"
        ? candidate.id.toString()
        : "";
  const title = typeof candidate.title === "string" ? candidate.title : "";
  const lat = typeof candidate.lat === "number" ? candidate.lat : NaN;
  const lon = typeof candidate.lon === "number" ? candidate.lon : NaN;
  const price =
    typeof candidate.price === "number" ? candidate.price : Number.NaN;
  const currency =
    typeof candidate.currency === "string" && candidate.currency.trim()
      ? candidate.currency.trim().toUpperCase()
      : "EUR";
  const countryCode = normalizeCountryCode(
    candidate.countryCode ?? candidate.country
  );
  if (!id || !title || !Number.isFinite(lat) || !Number.isFinite(lon)) {
    return null;
  }
  if (!Number.isFinite(price) || !countryCode) return null;
  const url = typeof candidate.url === "string" ? candidate.url : "";
  const source = candidate.source === "partner" ? "partner" : "mock";
  return {
    id,
    title,
    lat,
    lon,
    price,
    currency,
    countryCode,
    imageUrl: typeof candidate.imageUrl === "string" ? candidate.imageUrl : undefined,
    rating: typeof candidate.rating === "number" ? candidate.rating : undefined,
    url,
    source,
  };
};

const isValidStay = (entry: Stay) =>
  Boolean(
    entry &&
      typeof entry.id === "string" &&
      typeof entry.title === "string" &&
      typeof entry.lat === "number" &&
      typeof entry.lon === "number" &&
      typeof entry.price === "number" &&
      typeof entry.currency === "string" &&
      typeof entry.countryCode === "string" &&
      typeof entry.url === "string" &&
      (entry.source === "mock" || entry.source === "partner")
  );

const generateGlobalMockStays = (): Stay[] => {
  const stays: Stay[] = [];
  countryMeta.forEach((country) => {
    const code = normalizeCountryCode(country.code);
    if (!code || !Number.isFinite(country.lat) || !Number.isFinite(country.lon)) {
      return;
    }
    const cityCandidates: { name: string; lat: number; lon: number }[] = [];
    const baseName = country.capital?.trim() || country.name;
    if (baseName) {
      cityCandidates.push({ name: baseName, lat: country.lat, lon: country.lon });
    }
    (country.topCities ?? []).forEach((city) => {
      if (!city?.name) return;
      if (!Number.isFinite(city.lat) || !Number.isFinite(city.lon)) return;
      cityCandidates.push({ name: city.name, lat: city.lat, lon: city.lon });
    });
    const uniqueCities = Array.from(
      new Map(cityCandidates.map((city) => [city.name, city])).values()
    );
    if (!uniqueCities.length) return;

    const totalSeed = hashString(code);
    const totalRng = createRng(totalSeed);
    const totalStays = 6 + Math.floor(totalRng() * 7);
    for (let i = 0; i < totalStays; i += 1) {
      const city = uniqueCities[i % uniqueCities.length];
      const seed = hashString(`${code}-${city.name}-${i}`);
      const rng = createRng(seed);
      const lat = clampLat(city.lat + (rng() - 0.5) * 0.08);
      const lon = clampLon(city.lon + (rng() - 0.5) * 0.08);
      const price = 60 + Math.floor(rng() * 291);
      const rating = Number((4 + rng() * 0.9).toFixed(2));
      const imageUrl = imagePool[i % imagePool.length];
      stays.push({
        id: `${code}-${slugify(city.name)}-${i + 1}`,
        title: `Stay in ${city.name}`,
        lat,
        lon,
        price,
        currency: "EUR",
        countryCode: code,
        imageUrl,
        rating,
        url: "",
        source: "mock",
      });
    }
  });
  return stays;
};

const loadMockStays = async () => {
  if (staysCache) return staysCache;
  if (staysCachePromise) return staysCachePromise;
  staysCachePromise = (async () => {
    try {
      let parsed: unknown = [];
      try {
        const file = await fs.readFile(resolveMockPath(), "utf-8");
        parsed = JSON.parse(file) as unknown;
      } catch (fileError) {
        console.warn("[stays] Mock dataset not found, generating global stays.");
        parsed = [];
      }
      if (!Array.isArray(parsed)) {
        throw new ServiceError("Invalid mock stays dataset", {
          status: 500,
          code: "unexpected",
        });
      }
      const baseStays = parsed
        .map((entry) => normalizeStay(entry))
        .filter((entry): entry is Stay => Boolean(entry) && isValidStay(entry));
      const countrySet = new Set(baseStays.map((stay) => stay.countryCode));
      const total = baseStays.length;
      const esCount = baseStays.filter((stay) => stay.countryCode === "ES").length;
      const mostlySpain = total > 0 && esCount / total > 0.7;
      const tooSmall = countrySet.size < 10 || total < 10;
      if (!baseStays.length || mostlySpain || tooSmall) {
        const generated = generateGlobalMockStays();
        const merged = new Map<string, Stay>();
        baseStays.forEach((stay) => merged.set(stay.id, stay));
        generated.forEach((stay) => merged.set(stay.id, stay));
        staysCache = Array.from(merged.values());
        return staysCache;
      }
      staysCache = baseStays;
      return staysCache;
    } catch (error) {
      if (error instanceof ServiceError) throw error;
      throw new ServiceError("Failed to load mock stays dataset", {
        status: 500,
        code: "unexpected",
        cause: error,
      });
    } finally {
      staysCachePromise = null;
    }
  })();
  return staysCachePromise;
};

const isWithinBbox = (stay: Stay, bbox: Bbox) =>
  stay.lat >= bbox.minLat &&
  stay.lat <= bbox.maxLat &&
  stay.lon >= bbox.minLon &&
  stay.lon <= bbox.maxLon;

const matchesPrice = (stay: Stay, minPrice?: number, maxPrice?: number) => {
  if (Number.isFinite(minPrice) && stay.price < (minPrice as number)) {
    return false;
  }
  if (Number.isFinite(maxPrice) && stay.price > (maxPrice as number)) {
    return false;
  }
  return true;
};

export const fetchMockStays = async ({
  bbox,
  minPrice,
  maxPrice,
  currency,
  country,
  limit = 200,
}: StaySearchParams): Promise<Stay[]> => {
  const stays = await loadMockStays();
  const filtered = stays.filter((stay) => {
    if (country && stay.countryCode !== country) return false;
    if (!isWithinBbox(stay, bbox)) return false;
    if (currency && stay.currency !== currency) return false;
    return matchesPrice(stay, minPrice, maxPrice);
  });
  return filtered.slice(0, Math.min(limit, 200));
};
